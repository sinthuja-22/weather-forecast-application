import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [cached, setCached] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!city.trim()) return;

    setLoading(true);
    setError('');

    try {
      const response = await axios.get(
        `http://localhost:5000/api/weather?city=${encodeURIComponent(city)}`
      );
      setWeather(response.data.data);
      setCached(response.data.cached);
    } catch (err) {
      setWeather(null);
      if (err.response && err.response.data && err.response.data.error) {
        setError(err.response.data.error);
      } else {
        setError('Network error. Check backend configuration.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>Weather Forecast</h1>
      
      <form onSubmit={handleSearch} className="search-form">
        <input
          type="text"
          className="search-input"
          placeholder="Enter city name..."
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <button type="submit" className="search-btn" disabled={loading}>
          {loading ? '...' : 'Search'}
        </button>
      </form>

      {error && <div className="error-banner">{error}</div>}

      {weather && (
        <div className="weather-card">
          <div className="location">
            {weather.city}, {weather.country}
          </div>

          <div className="weather-main">
            <img
              src={`https://openweathermap.org/img/wn/${weather.icon}@2x.png`}
              alt={weather.description}
            />
            <div className="temp">{weather.temp}°C</div>
          </div>

          <div className="condition">{weather.description}</div>

          <div className="details-grid">
            <div className="detail-item">
              Feels Like
              <span className="detail-value">{weather.feelsLike}°C</span>
            </div>
            <div className="detail-item">
              Humidity
              <span className="detail-value">{weather.humidity}%</span>
            </div>
            <div className="detail-item">
              Wind Speed
              <span className="detail-value">{weather.windSpeed} m/s</span>
            </div>
            <div className="detail-item">
              Min / Max
              <span className="detail-value">
                {weather.tempMin}° / {weather.tempMax}°
              </span>
            </div>
          </div>

          {cached && <span className="cache-badge">Fetched from cache</span>}
        </div>
      )}
    </div>
  );
}

export default App;