const express = require('express');
const axios = require('axios');
const cors = require('cors');
const NodeCache = require('node-cache');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Initialize cache with 10-minute (600 seconds) default expiration
const cache = new NodeCache({ stdTTL: 600 });

// Middleware
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000' }));
app.use(express.json());

// Routes
app.get('/api/weather', async (req, res) => {
  const { city } = req.query;

  if (!city || typeof city !== 'string' || city.trim() === '') {
    return res.status(400).json({ error: 'A valid city name is required.' });
  }

  const normalizedCity = city.trim().toLowerCase();

  // 1. Check cache first
  if (cache.has(normalizedCity)) {
    return res.json({
      cached: true,
      data: cache.get(normalizedCity)
    });
  }

  // 2. Fetch from OpenWeatherMap API
  try {
    const apiKey = process.env.OPENWEATHER_API_KEY;
    if (!apiKey || apiKey === 'your_actual_openweather_api_key_here') {
      return res.status(500).json({ error: 'Server configuration error: Missing API Key.' });
    }

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(
      normalizedCity
    )}&units=metric&appid=${apiKey}`;

    const response = await axios.get(url);
    const { name, main, weather, wind, sys } = response.data;

    const payload = {
      city: name,
      country: sys.country,
      temp: Math.round(main.temp),
      feelsLike: Math.round(main.feels_like),
      humidity: main.humidity,
      tempMin: Math.round(main.temp_min),
      tempMax: Math.round(main.temp_max),
      windSpeed: wind.speed,
      condition: weather[0].main,
      description: weather[0].description,
      icon: weather[0].icon
    };

    // Store in cache
    cache.set(normalizedCity, payload);

    return res.json({
      cached: false,
      data: payload
    });
  } catch (error) {
    if (error.response) {
      if (error.response.status === 404) {
        return res.status(404).json({ error: 'City not found. Please verify the name.' });
      }
      return res.status(error.response.status).json({
        error: error.response.data.message || 'Error fetching external weather data.'
      });
    }
    return res.status(500).json({ error: 'Unable to connect to weather service.' });
  }
});

app.listen(PORT, () => {
  console.log(`Server executing on port ${PORT}`);
});